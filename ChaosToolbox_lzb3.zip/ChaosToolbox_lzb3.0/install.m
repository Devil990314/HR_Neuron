function [] = install()

addpath([pwd,'\BoxDimension_2D']);
addpath([pwd,'\BoxDimension_TS']);
addpath([pwd,'\C-C Method']);
addpath([pwd,'\C-C Method Improved']);
addpath([pwd,'\ChaosAttractors']);
addpath([pwd,'\CorrelationDimension_GP']);
addpath([pwd,'\DelayTime_MutualInformation']);
addpath([pwd,'\DelayTime_Others']);
addpath([pwd,'\EmbeddingDimension_FNN']);
addpath([pwd,'\GeneralizedDimension_2D']);
addpath([pwd,'\GeneralizedDimension_TS']);
addpath([pwd,'\KolmogorovEntropy_GP']);
addpath([pwd,'\KolmogorovEntropy_STB']);
addpath([pwd,'\LargestLyapunov_Rosenstein']);
addpath([pwd,'\LyapunovSpectrum_BBA']);
addpath([pwd,'\Prediction_RBF']);
addpath([pwd,'\Prediction_Volterra']);
addpath([pwd,'\SurrogateData']);

disp('--------------- ��װ�ɹ� -----------------')